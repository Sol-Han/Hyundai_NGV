#include "ros/ros.h"
#include "cpp_example_pkg/Counts.h"

void msgCallback(const cpp_example_pkg::Counts::ConstPtr& msg)
{
    ROS_INFO("Recieve msg");
    ROS_INFO("time : %d", msg->stamp.sec); 
    ROS_INFO("count : %d", msg->count);
    ROS_INFO("count square : %d", msg->square);
    ROS_INFO("count cubic : %d", msg->cubic);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "listener");
    ros::NodeHandle nh;
    ros::Subscriber ros_tutorial_sub = nh.subscribe("chatter", 100, msgCallback);
    ros::spin();
    return 0;
}

