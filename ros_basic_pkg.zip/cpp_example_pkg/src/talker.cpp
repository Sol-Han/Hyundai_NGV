#include "ros/ros.h"
#include "cpp_example_pkg/Counts.h"
#include<cmath>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "talker");
    ros::NodeHandle nh;

    ros::Publisher pub = nh.advertise<cpp_example_pkg::Counts>("chatter", 100);
    ros::Rate loop_rate(1);
    cpp_example_pkg::Counts msg;
    int count = 0;

    while (ros::ok())
    {
        msg.stamp = ros::Time::now(); 
        msg.count = count;
        msg.square = int(pow(count, 2));
        msg.cubic = int(pow(count, 3));
        ROS_INFO("Send msg");
        ROS_INFO("time : %d", msg.stamp.sec);
        ROS_INFO("count : %d", msg.count);
        ROS_INFO("count square : %d", msg.square);
        ROS_INFO("count cubic : %d", msg.cubic);
        pub.publish(msg);
        loop_rate.sleep();
        count++;
    }
    return 0;
}

