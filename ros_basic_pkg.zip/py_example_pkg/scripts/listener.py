#!/usr/bin/env python3
import rospy
from py_example_pkg.msg import Counts

def callback(data):
    rospy.loginfo("Recieve msg")
    rospy.loginfo("time : %d", data.stamp.secs)
    rospy.loginfo("count : %d", data.count)
    rospy.loginfo("count square : %d", data.square)
    rospy.loginfo("count cubic : %d", data.cubic)

def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber("chatter", Counts, callback)
    rospy.spin()

if __name__ == '__main__':
    listener()