#!/usr/bin/env python3
import rospy
from py_example_pkg.msg import Counts

def talker():
    pub = rospy.Publisher('chatter', Counts)
    rospy.init_node('talker', anonymous=True)
    r = rospy.Rate(1)
    msg = Counts()
    count = 0
    while not rospy.is_shutdown():
        msg.stamp = rospy.Time.now()
        msg.count = count
        msg.square = count**2
        msg.cubic = count**3
        rospy.loginfo("Send msg")
        rospy.loginfo("time : %d", msg.stamp.secs)
        rospy.loginfo("count : %d", msg.count)
        rospy.loginfo("count square : %d", msg.square)
        rospy.loginfo("count cubic : %d", msg.cubic)
        pub.publish(msg)
        count += 1
        r.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException: pass   