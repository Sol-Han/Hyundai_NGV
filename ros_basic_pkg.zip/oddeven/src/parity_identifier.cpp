#include "ros/ros.h"                          // ROS Default Header File
#include "oddeven/number.h"  // number Message File Header. The header file is automatically created when building the package.
#include "oddeven/number_parity.h" // number_parity Message File Header. The header file is automatically created when building the package.

//Define class for publisher and subscriber in the same node
class SubandPub 
{
    public:
        SubandPub()
        {z
            pub = nh.advertise<oddeven::number_parity>("number_oddeven", 100); // publisher with topic name "number_oddeven"
            sub = nh.subscribe("number", 100, &SubandPub::callback, this); // Subscribe from number topoc
        }

        void callback(const oddeven::number::ConstPtr& msg) // subscriber callback function
        {
            oddeven::number_parity parity_msg;
            parity_msg.number = msg->number;
            if((msg->number)%2 == 0){ // number is even
                ROS_INFO("even");
                parity_msg.parity = "even";
            }else{ // number is odd
                ROS_INFO("odd");
                parity_msg.parity = "odd";
            }
            pub.publish(parity_msg); // publish
        }

    private:
        ros::NodeHandle nh;
        ros::Publisher pub;
        ros::Subscriber sub;

};

int main(int argc, char **argv)
{
  //Initiate ROS
  ros::init(argc, argv, "parity_identifier");

  //Create an object of class SubscribeAndPublish that will take care of everything
  SubandPub SAPObject; 

  ros::spin();

  return 0;
}
