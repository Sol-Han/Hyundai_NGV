#include "ros/ros.h"                            // ROS Default Header File
#include "oddeven/number.h"    // number Message File Header. The header file is automatically created when building the package.

int main(int argc, char **argv)                 // Node Main Function
{
  ros::init(argc, argv, "number_publisher");     // Initializes Node Name
  ros::NodeHandle nh;                           // Node handle declaration for communication with ROS system
  ros::Publisher number_pub = nh.advertise<oddeven::number>("number", 100); // define publisher with topic name "number"

  // Set the loop period. '1' refers to 1 Hz and the main loop repeats at 1 second intervals
  ros::Rate loop_rate(1);

  oddeven::number msg;     // Declares message 'msg' in 'number' message file format
  int num = 0;                            // Variable to be used in message

  while (ros::ok())
  {
    msg.number  = num;                      // Save the the 'num' value in the data of 'msg'

    ROS_INFO("send msg = %d", msg.number);        // Prints the 'number' message

    number_pub.publish(msg);          // Publishes 'msg' message

    loop_rate.sleep();                      // Goes to sleep according to the loop rate defined above.

    ++num;                                // Increase num variable by one
  }

  return 0;
}