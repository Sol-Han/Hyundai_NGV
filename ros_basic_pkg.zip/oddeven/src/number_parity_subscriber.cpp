#include "ros/ros.h"                        // ROS Default Header File
#include "oddeven/number_parity.h"  // number_parity Message File Header. The header file is automatically created when building the package.

void msgCallback(const oddeven::number_parity::ConstPtr& msg)
{
  ROS_INFO("%d is an %s number", msg->number, msg->parity.c_str());   // Prints the 'number_parity' message
}

int main(int argc, char **argv)                         // Node Main Function
{
  ros::init(argc, argv, "number_parity_subscriber");            // Initializes Node Name

  ros::NodeHandle nh;                                   // Node handle declaration for communication with ROS system

  ros::Subscriber number_parity_sub = nh.subscribe("number_oddeven", 100, msgCallback); // subscribe from number_oddeven topic

  // A function for calling a callback function, waiting for a message to be
  // received, and executing a callback function when it is received.
  ros::spin();

  return 0;
}